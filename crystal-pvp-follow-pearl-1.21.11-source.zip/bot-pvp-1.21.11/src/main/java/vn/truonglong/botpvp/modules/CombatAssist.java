package vn.truonglong.botpvp.modules;

import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;

/** Combat settings scaffold; does not send attack actions. */
public class CombatAssist extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    public final Setting<Boolean> autoTarget = sg.add(new BoolSetting.Builder().name("auto-target").description("Target selection is provided by the movement module; this is a reserved option.").defaultValue(true).build());
    public final Setting<Boolean> autoAttack = sg.add(new BoolSetting.Builder().name("auto-attack").description("Reserved toggle only; automatic attacking is not implemented.").defaultValue(false).build());
    public final Setting<Double> hitRange = sg.add(new DoubleSetting.Builder().name("attack-range").description("Reserved attack range setting.").defaultValue(3.0).min(1.0).max(6.0).sliderMin(1.0).sliderMax(6.0).build());
    public final Setting<Boolean> friendProtection = sg.add(new BoolSetting.Builder().name("friend-protection").description("Reserved option for friend filtering.").defaultValue(true).build());
    public CombatAssist() { super(Categories.Combat, "bot-pvp-combat-settings", "Combat configuration scaffold; automatic attacks are not implemented."); }
}

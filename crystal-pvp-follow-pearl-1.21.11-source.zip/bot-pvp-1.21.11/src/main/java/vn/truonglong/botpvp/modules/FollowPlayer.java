package vn.truonglong.botpvp.modules;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/**
 * Basic client-side follow-player helper.
 * It follows the nearest eligible player in range by steering yaw and holding
 * the forward key. This is not a server-side bot and does not pathfind around
 * complex obstacles.
 */
public class FollowPlayer extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Double> searchRange = sg.add(new DoubleSetting.Builder()
        .name("search-range")
        .description("Maximum distance to find a player to follow.")
        .defaultValue(32.0).min(4.0).max(128.0).sliderMin(4.0).sliderMax(64.0)
        .build());

    private final Setting<Double> stopDistance = sg.add(new DoubleSetting.Builder()
        .name("stop-distance")
        .description("Stop walking when closer than this distance.")
        .defaultValue(2.5).min(1.0).max(8.0).sliderMin(1.0).sliderMax(6.0)
        .build());

    private final Setting<Boolean> usePearl = sg.add(new BoolSetting.Builder()
        .name("use-ender-pearl")
        .description("Automatically throw an Ender Pearl from the hotbar when the target is far away.")
        .defaultValue(false)
        .build());

    private final Setting<Double> pearlDistance = sg.add(new DoubleSetting.Builder()
        .name("pearl-distance")
        .description("Throw a pearl when farther than this distance.")
        .defaultValue(16.0).min(6.0).max(64.0).sliderMin(6.0).sliderMax(40.0)
        .build());

    private PlayerEntity target;
    private int pearlCooldown;

    public FollowPlayer() {
        super(Categories.Movement, "follow-player",
            "Follows the nearest player; optionally uses Ender Pearls from the hotbar when far away.");
    }

    @Override
    public void onDeactivate() {
        releaseMovement();
        target = null;
        pearlCooldown = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) {
            releaseMovement();
            target = null;
            return;
        }

        if (pearlCooldown > 0) pearlCooldown--;
        target = null;
        double best = searchRange.get() * searchRange.get();
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || player.isRemoved() || player.isSpectator() || player.isDead()) continue;
            double distance = mc.player.squaredDistanceTo(player);
            if (distance < best) {
                best = distance;
                target = player;
            }
        }

        if (target == null) {
            releaseMovement();
            return;
        }

        double distance = Math.sqrt(mc.player.squaredDistanceTo(target));

        if (usePearl.get() && distance >= pearlDistance.get() && pearlCooldown == 0) {
            int pearlSlot = findPearlSlot();
            if (pearlSlot >= 0) {
                int oldSlot = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = pearlSlot;

                double dxPearl = target.getX() - mc.player.getX();
                double dyPearl = target.getY() + target.getStandingEyeHeight() * 0.65
                    - (mc.player.getY() + mc.player.getStandingEyeHeight());
                double dzPearl = target.getZ() - mc.player.getZ();
                double horizontal = Math.sqrt(dxPearl * dxPearl + dzPearl * dzPearl);
                float pearlYaw = (float) (Math.toDegrees(Math.atan2(dzPearl, dxPearl)) - 90.0);
                float pearlPitch = (float) -Math.toDegrees(Math.atan2(dyPearl, horizontal));

                mc.player.setYaw(pearlYaw);
                mc.player.setPitch(Math.max(-45.0f, Math.min(45.0f, pearlPitch)));
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                mc.player.getInventory().selectedSlot = oldSlot;
                pearlCooldown = 40;
                releaseMovement();
                return;
            }
        }

        if (distance <= stopDistance.get()) {
            releaseMovement();
            return;
        }

        double dx = target.getX() - mc.player.getX();
        double dz = target.getZ() - mc.player.getZ();
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        mc.player.setYaw(yaw);
        mc.options.forwardKey.setPressed(true);
        mc.options.backKey.setPressed(false);
        mc.options.leftKey.setPressed(false);
        mc.options.rightKey.setPressed(false);
        mc.options.sprintKey.setPressed(distance > 6.0);
    }

    private int findPearlSlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.ENDER_PEARL)) return i;
        }
        return -1;
    }

    private void releaseMovement() {
        if (mc.options == null) return;
        mc.options.forwardKey.setPressed(false);
        mc.options.backKey.setPressed(false);
        mc.options.leftKey.setPressed(false);
        mc.options.rightKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);
    }

    @Override
    public String getInfoString() {
        return target == null ? "No target" : target.getName().getString();
    }
}

package vn.truonglong.botpvp.modules;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;

/** Optional PvP target helper. Aim and attack automation are disabled by default. */
public class BotPvpCombat extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
        .name("target-range").description("Maximum distance for finding a player target.")
        .defaultValue(4.0).min(2.0).max(6.0).sliderMin(2.0).sliderMax(6.0).build());

    private final Setting<Boolean> aimAssist = sgGeneral.add(new BoolSetting.Builder()
        .name("aim-assist").description("Gently turns toward the nearest target.")
        .defaultValue(false).build());

    private final Setting<Boolean> attackAssist = sgGeneral.add(new BoolSetting.Builder()
        .name("attack-assist").description("Attacks the selected target when in range and the attack cooldown is ready. Disabled by default.")
        .defaultValue(false).build());

    private final Setting<Double> turnSpeed = sgGeneral.add(new DoubleSetting.Builder()
        .name("turn-speed").description("Maximum fraction of the angle corrected each tick.")
        .defaultValue(0.25).min(0.05).max(1.0).sliderMin(0.05).sliderMax(1.0)
        .visible(aimAssist::get).build());

    private PlayerEntity target;

    public BotPvpCombat() {
        super(Categories.Combat, "bot-pvp-combat", "Finds a nearby player and provides optional aim and attack assistance.");
    }

    @Override
    public void onActivate() {
        MeteorClient.EVENT_BUS.subscribe(this);
        target = null;
    }

    @Override
    public void onDeactivate() {
        MeteorClient.EVENT_BUS.unsubscribe(this);
        target = null;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            target = null;
            return;
        }

        target = null;
        double bestDistance = range.get() * range.get();
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || player.isRemoved() || player.isSpectator() || player.isDead()) continue;
            double distance = mc.player.squaredDistanceTo(player);
            if (distance <= bestDistance) {
                bestDistance = distance;
                target = player;
            }
        }

        if (target == null) return;

        if (aimAssist.get()) aimAtTarget();
        if (attackAssist.get() && mc.player.distanceTo(target) <= range.get()
            && mc.player.getAttackCooldownProgress(0.5f) >= 1.0f) {
            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }

    private void aimAtTarget() {
        double dx = target.getX() - mc.player.getX();
        double dz = target.getZ() - mc.player.getZ();
        double dy = target.getEyeY() - mc.player.getEyeY();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float wantedYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float wantedPitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        float factor = turnSpeed.get().floatValue();
        mc.player.setYaw(mc.player.getYaw() + MathHelper.wrapDegrees(wantedYaw - mc.player.getYaw()) * factor);
        mc.player.setPitch(mc.player.getPitch() + MathHelper.wrapDegrees(wantedPitch - mc.player.getPitch()) * factor);
    }

    @Override
    public String getInfoString() {
        return target == null ? "No target" : target.getName().getString();
    }
}

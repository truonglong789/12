package vn.truonglong.botpvp;

import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Modules;
import vn.truonglong.botpvp.modules.AnchorPvP;
import vn.truonglong.botpvp.modules.BotPvpCombat;
import vn.truonglong.botpvp.modules.BotTasks;
import vn.truonglong.botpvp.modules.CombatAssist;
import vn.truonglong.botpvp.modules.CrystalPvP;
import vn.truonglong.botpvp.modules.FollowPlayer;
import vn.truonglong.botpvp.modules.PvpMoveAssist;

public class BotPvpAddon extends MeteorAddon {
    @Override public void onInitialize() {
        Modules.get().add(new PvpMoveAssist());
        Modules.get().add(new FollowPlayer());
        Modules.get().add(new BotPvpCombat());
        Modules.get().add(new CombatAssist());
        Modules.get().add(new CrystalPvP());
        Modules.get().add(new AnchorPvP());
        Modules.get().add(new BotTasks());
        System.out.println("[Bot-PvP] Addon loaded (some modules are configuration scaffolds).");
    }
    @Override public String getPackage() { return "vn.truonglong.botpvp"; }
}

package vn.truonglong.botpvp.modules;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import meteordevelopment.meteorclient.MeteorClient;

/** Conservative first version: selects a nearby player and displays target info; movement assistance is opt-in. */
public class PvpMoveAssist extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
        .name("range").description("Maximum distance to detect another player.")
        .defaultValue(4.0).min(2.0).max(6.0).sliderMin(2.0).sliderMax(6.0).build());
    private final Setting<Boolean> strafe = sgGeneral.add(new BoolSetting.Builder()
        .name("strafe-assist").description("Gently alternates left/right movement near a target; does not attack automatically.")
        .defaultValue(false).build());
    private int strafeTicks;
    private boolean left = true;
    private PlayerEntity target;

    public PvpMoveAssist() { super(Categories.Combat, "bot-pvp", "Detects nearby player targets and optionally assists strafing. No automatic attacks."); }

    @Override public void onActivate() {
        MeteorClient.EVENT_BUS.subscribe(this);
        strafeTicks = 0;
    }

    @Override public void onDeactivate() {
        MeteorClient.EVENT_BUS.unsubscribe(this);
        target = null;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;
        target = null;
        double best = range.get() * range.get();
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || player.isRemoved() || player.isSpectator()) continue;
            double d = mc.player.squaredDistanceTo(player);
            if (d < best) { best = d; target = player; }
        }
        // Minecraft 1.21.11 changed its input API. This version safely tracks the
        // nearest target and exposes it in the module info; strafe input is not
        // written directly because doing so is version-dependent.
        if (target != null && strafe.get()) {
            if (++strafeTicks >= 8) { strafeTicks = 0; left = !left; }
        }
    }

    @Override public String getInfoString() { return target == null ? "No target" : target.getName().getString(); }
}

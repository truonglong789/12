package vn.truonglong.botpvp.modules;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Crystal PvP module for Meteor Client 86 / Minecraft 1.21.11.
 * Implements nearest-player targeting, crystal breaking, basic safe-base
 * crystal placement, and an action-bar target HUD. Damage prediction and
 * advanced placement scoring are intentionally not claimed as implemented.
 */
public class CrystalPvP extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Boolean> autoTarget = sg.add(new BoolSetting.Builder()
        .name("auto-target").description("Track the nearest eligible player in range.")
        .defaultValue(true).build());

    private final Setting<Boolean> autoCrystal = sg.add(new BoolSetting.Builder()
        .name("auto-crystal").description("Place an End Crystal on a nearby valid obsidian/bedrock base when holding a crystal.")
        .defaultValue(false).build());

    private final Setting<Boolean> crystalBreaker = sg.add(new BoolSetting.Builder()
        .name("crystal-breaker").description("Attack nearby End Crystal entities.")
        .defaultValue(true).build());

    private final Setting<Boolean> targetHud = sg.add(new BoolSetting.Builder()
        .name("crystal-pvp-hud").description("Show target name, health, and distance in the action bar.")
        .defaultValue(true).build());

    private final Setting<Double> range = sg.add(new DoubleSetting.Builder()
        .name("range").description("Target and crystal interaction range.")
        .defaultValue(4.0).min(1.0).max(6.0).sliderMin(1.0).sliderMax(6.0).build());

    private final Setting<Boolean> smartBase = sg.add(new BoolSetting.Builder()
        .name("smart-base").description("Only attempt placement on obsidian/bedrock with two air blocks above.")
        .defaultValue(true).build());

    private PlayerEntity target;
    private int cooldown;

    public CrystalPvP() {
        super(Categories.Combat, "crystal-pvp-assist",
            "Basic Crystal PvP: nearest target, crystal breaking, valid-base placement, and action-bar HUD.");
    }

    @Override
    public void onDeactivate() {
        target = null;
        cooldown = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (cooldown > 0) cooldown--;

        target = null;
        if (autoTarget.get()) {
            double best = range.get() * range.get();
            for (PlayerEntity player : mc.world.getPlayers()) {
                if (player == mc.player || player.isRemoved() || player.isSpectator()) continue;
                if (player.isDead()) continue;
                double d = mc.player.squaredDistanceTo(player);
                if (d <= best) {
                    best = d;
                    target = player;
                }
            }
        }

        if (targetHud.get()) {
            if (target == null) {
                mc.player.sendMessage(net.minecraft.text.Text.literal("Crystal PvP | No target"), true);
            } else {
                double distance = Math.sqrt(mc.player.squaredDistanceTo(target));
                String label = String.format("Crystal PvP | %s | %.1f HP | %.1fm",
                    target.getName().getString(), target.getHealth(), distance);
                mc.player.sendMessage(net.minecraft.text.Text.literal(label), true);
            }
        }

        if (cooldown > 0) return;

        if (crystalBreaker.get() && breakNearbyCrystal()) {
            cooldown = 2;
            return;
        }

        if (autoCrystal.get() && target != null && placeCrystalAtTargetBase()) {
            cooldown = 3;
        }
    }

    private boolean breakNearbyCrystal() {
        double max = range.get() * range.get();
        EndCrystalEntity nearest = null;
        double best = max;
        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof EndCrystalEntity crystal) || crystal.isRemoved()) continue;
            double d = mc.player.squaredDistanceTo(crystal);
            if (d <= best) {
                best = d;
                nearest = crystal;
            }
        }
        if (nearest == null) return false;
        mc.interactionManager.attackEntity(mc.player, nearest);
        mc.player.swingHand(Hand.MAIN_HAND);
        return true;
    }

    private boolean placeCrystalAtTargetBase() {
        if (!mc.player.getMainHandStack().isOf(Items.END_CRYSTAL)) return false;
        BlockPos targetPos = target.getBlockPos();
        int radius = 2;
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                BlockPos base = targetPos.add(x, -1, z);
                if (mc.player.squaredDistanceTo(Vec3d.ofCenter(base)) > range.get() * range.get()) continue;
                var block = mc.world.getBlockState(base).getBlock();
                if (smartBase.get() && block != Blocks.OBSIDIAN && block != Blocks.BEDROCK) continue;
                if (!smartBase.get() && block != Blocks.OBSIDIAN && block != Blocks.BEDROCK) continue;
                if (!mc.world.getBlockState(base.up()).isAir()) continue;
                if (!mc.world.getBlockState(base.up(2)).isAir()) continue;

                Vec3d hitPos = Vec3d.ofCenter(base).add(0, 0.5, 0);
                BlockHitResult hit = new BlockHitResult(hitPos, Direction.UP, base, false);
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
                mc.player.swingHand(Hand.MAIN_HAND);
                return true;
            }
        }
        return false;
    }

    @Override
    public String getInfoString() {
        return target == null ? "No target" : target.getName().getString();
    }
}

package vn.truonglong.botpvp.modules;

import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;

/** Roadmap/settings panel for Mineflayer-style tasks. Toggles are intentionally not wired to automation yet. */
public class BotTasks extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    public final Setting<Boolean> followPlayer = sg.add(new BoolSetting.Builder().name("follow-player").description("Roadmap toggle only: follow-player task is not implemented in this Java addon yet.").defaultValue(false).build());
    public final Setting<Boolean> farming = sg.add(new BoolSetting.Builder().name("farm-tasks").description("Roadmap toggle only: crop/fishing automation is not implemented yet.").defaultValue(false).build());
    public final Setting<Boolean> mining = sg.add(new BoolSetting.Builder().name("mining-tasks").description("Roadmap toggle only: !mine-style block collection is not implemented yet.").defaultValue(false).build());
    public final Setting<Boolean> litematicBuild = sg.add(new BoolSetting.Builder().name("litematic-build").description("Roadmap toggle only: Litematica parsing/build automation is not implemented yet.").defaultValue(false).build());
    public final Setting<Boolean> inventoryTools = sg.add(new BoolSetting.Builder().name("inventory-tools").description("Roadmap toggle only: inventory transfer commands are not implemented yet.").defaultValue(false).build());
    public BotTasks() { super(Categories.Misc, "bot-tasks-roadmap", "Mineflayer-inspired task options. These toggles are placeholders, not working automation."); }
}

# Bot PvP Meteor addon — Crystal PvP starter

Target: Minecraft 1.21.11, Yarn 1.21.11+build.6, Fabric Loader 0.19.3, Meteor Client 86.
Java 21 is required.

## Build
1. Open this folder in GitHub Codespaces.
2. Run `gradle build --console=plain`.
3. The addon JAR is in `build/libs/` (choose `bot-pvp-1.0.0.jar`, not `-sources.jar`).
4. Put the JAR in the same Minecraft instance's `mods` folder as Meteor Client.

The project includes local dependencies in `libs/` so the build does not need to fetch Meteor itself.

## Crystal PvP module (`crystal-pvp-assist`)
Implemented in source:
- nearest eligible player target within configured range;
- crystal breaker that attacks nearby End Crystal entities;
- basic placement attempt on a valid obsidian/bedrock base with two air blocks above, when an End Crystal is held;
- action-bar HUD with target name, health, and distance;
- `follow-player` movement module: finds the nearest player in range, turns toward them, walks forward, and stops at the configured distance;
- range setting and toggles.

Important limits:
- This is a basic assist module, not a fully optimized Crystal PvP combat system.
- It does not calculate explosion/self damage, predict enemy movement, place obsidian automatically, swap inventory slots, or implement a complete smart-placement score.
- The auto-placement logic requires the End Crystal to already be in the main hand and may need adjustment after compiling/testing against the exact Meteor/Minecraft mappings.
- `Bot Tasks`, Anchor PvP and other modules in this starter are still scaffolds/placeholders; they have not been ported completely from the Mineflayer ZIP.
- A successful build only proves compilation, not that every gameplay feature works on every server.

## Follow player
Enable `follow-player` under Meteor's Movement category. It follows the nearest eligible player in search range and stops at the selected distance. This is basic steering, not full obstacle-aware pathfinding; test in a safe/private world first. Disabling the module releases the movement keys.


## Follow Player: Ender Pearl
The `follow-player` module now has an optional `use-ender-pearl` setting (off by default).
When enabled, if the selected target is at least `pearl-distance` blocks away and an Ender Pearl
is found in the hotbar, it briefly selects that slot, aims toward the target, uses the pearl, and
returns to walking follow after a cooldown. This is a basic aim heuristic, not guaranteed to land
beside moving targets; server anti-cheat/cooldowns and pearl availability can affect it.
